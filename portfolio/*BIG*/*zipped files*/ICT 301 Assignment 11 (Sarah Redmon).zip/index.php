<html>
<body>
<table width="700" cellpadding="10">
<tr><td>
<a href="index.php">Home</a>
<a href="register.php">Register</a>
<a href="index.php">Login</a>
</td></tr>
</table>

<h2>Please Login here to use our service</h2>
<form action="login.php" method="post">
    <p>Email Address: <input type="email" name="email" size="20" maxlength="60"> </p>
    <p>Password: <input type="password" name="pass" size="20" maxlength="20"></p>
    <p><input type="submit" name="submit" value="Login"></p>
</form>
</body>
</html>