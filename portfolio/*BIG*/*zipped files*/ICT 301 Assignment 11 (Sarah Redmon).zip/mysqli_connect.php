<?php
DEFINE('DB_USER', 'skre230');
DEFINE('DB_PASSWORD', '7nq&1O1cPaVQm[a9');
DEFINE('DB_HOST', 'localhost');
DEFINE('DB_NAME', 'skre230ict301');

$dbc = @mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME) OR die('Could not connect to MySQL: ' . mysqli_connect_error());

if ($dbc) {
    echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>";
    echo "<strong><em>Connection to database successful</em></strong><br>";
    echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>";
}
?>